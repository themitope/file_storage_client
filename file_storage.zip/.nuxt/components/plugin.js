import Vue from 'vue'
import { wrapFunctional } from './utils'

const components = {
  Features: () => import('../..\\components\\Features.vue' /* webpackChunkName: "components/features" */).then(c => wrapFunctional(c.default || c)),
  Hero: () => import('../..\\components\\Hero.vue' /* webpackChunkName: "components/hero" */).then(c => wrapFunctional(c.default || c)),
  MyFooter: () => import('../..\\components\\MyFooter.vue' /* webpackChunkName: "components/my-footer" */).then(c => wrapFunctional(c.default || c)),
  NavBar: () => import('../..\\components\\NavBar.vue' /* webpackChunkName: "components/nav-bar" */).then(c => wrapFunctional(c.default || c)),
  Pricing: () => import('../..\\components\\Pricing.vue' /* webpackChunkName: "components/pricing" */).then(c => wrapFunctional(c.default || c)),
  SignIn: () => import('../..\\components\\SignIn.vue' /* webpackChunkName: "components/sign-in" */).then(c => wrapFunctional(c.default || c)),
  SignUp: () => import('../..\\components\\SignUp.vue' /* webpackChunkName: "components/sign-up" */).then(c => wrapFunctional(c.default || c))
}

for (const name in components) {
  Vue.component(name, components[name])
  Vue.component('Lazy' + name, components[name])
}
