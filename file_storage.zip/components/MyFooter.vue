<template>
    <footer>
        <div class="container">
            <div class="row pt-4">
                <div class="col-md-4">
                    <img src="@/static/images/logo.png" alt="">
                    <div class="mt-3" style="color: #a5abee">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat voluptas praesentium velit. Est facilis omnis exercitationem dolores similique ut reprehenderit, consequatur ducimus voluptas repellat architecto?
                    </div>
                </div>
                <div class="col-md-4">
                    <h5 class="mt-2">Quick Links</h5>
                    <div>
                        <p><a href="" class="mt-3" style="color: #a5abee">About Us</a></p>
                        <p><a href="" class="mt-3" style="color: #a5abee">Features</a></p>
                        <p><a href="" class="mt-3" style="color: #a5abee">Pricing</a></p>
                        <p><a href="" class="mt-3" style="color: #a5abee">Signin</a></p>
                    </div>
                </div>
                <div class="col-md-4">
                    <h5 class="mt-2">Contact</h5>
                    <div class="mt-3" style="color: #a5abee">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat voluptas praesentium velit.
                    </div>
                    <div class="d-flex mt-5">
                        <a href="http://facebook.com" target="_blank" rel="noopener noreferrer" class="my_icon mr-3">
                            <i class="fa fa-facebook" style="font-size: 16px"></i>
                        </a>
                        <a href="http://facebook.com" target="_blank" rel="noopener noreferrer" class="my_icon mr-3">
                            <i class="fa fa-twitter" style="font-size: 16px"></i>
                        </a>
                        <a href="http://facebook.com" target="_blank" rel="noopener noreferrer" class="my_icon">
                            <i class="fa fa-linkedin" style="font-size: 16px"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row pt-5 pb-5">
                <div class="col-md-8" style="color: #a5abee">
                    &copy;tfile 2021. All right reserved
                </div>
                <div class="col-md-4" style="color: #a5abee"    >
                    Designed by <a href="https://ogunleyeoluwatosin.herokuapp.com/">TTech</a>
                </div>
            </div>
        </div>
    </footer>
</template>

<script>
export default {

}
</script>

<style>
    .my_icon{
        background-color: #a5abee;
        padding: 3px 8px;
        color: #000000;
        border-radius: 5px;
    }
</style>