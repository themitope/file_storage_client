import { wrapFunctional } from './utils'

export { default as Features } from '../..\\components\\Features.vue'
export { default as Hero } from '../..\\components\\Hero.vue'
export { default as MyFooter } from '../..\\components\\MyFooter.vue'
export { default as NavBar } from '../..\\components\\NavBar.vue'
export { default as Pricing } from '../..\\components\\Pricing.vue'
export { default as SignIn } from '../..\\components\\SignIn.vue'
export { default as SignUp } from '../..\\components\\SignUp.vue'

export const LazyFeatures = import('../..\\components\\Features.vue' /* webpackChunkName: "components/features" */).then(c => wrapFunctional(c.default || c))
export const LazyHero = import('../..\\components\\Hero.vue' /* webpackChunkName: "components/hero" */).then(c => wrapFunctional(c.default || c))
export const LazyMyFooter = import('../..\\components\\MyFooter.vue' /* webpackChunkName: "components/my-footer" */).then(c => wrapFunctional(c.default || c))
export const LazyNavBar = import('../..\\components\\NavBar.vue' /* webpackChunkName: "components/nav-bar" */).then(c => wrapFunctional(c.default || c))
export const LazyPricing = import('../..\\components\\Pricing.vue' /* webpackChunkName: "components/pricing" */).then(c => wrapFunctional(c.default || c))
export const LazySignIn = import('../..\\components\\SignIn.vue' /* webpackChunkName: "components/sign-in" */).then(c => wrapFunctional(c.default || c))
export const LazySignUp = import('../..\\components\\SignUp.vue' /* webpackChunkName: "components/sign-up" */).then(c => wrapFunctional(c.default || c))
