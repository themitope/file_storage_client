import Vue from 'vue';
import VueTyperPlugin from 'vue-typer'
// CommonJS
//var VueTyperPlugin = require('vue-typer').default
// Global
//var VueTyperPlugin = window.VueTyper.default

Vue.use(VueTyperPlugin)